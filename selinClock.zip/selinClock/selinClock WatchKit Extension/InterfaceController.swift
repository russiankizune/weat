//
//  InterfaceController.swift
//  selinClock WatchKit Extension
//
//  Created by Гость on 01.04.2022.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController, CLLocationManagerDelegate
{

    override func awake(withContext context: Any?)
    {
        startLocationManager()
        // Configure interface objects here.
    }
    
    override func willActivate()
    {
        startLocationManager()
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate()
    {
        // This method is called when watch view controller is no longer visible
    }



        @IBOutlet weak var weatherIconImageView: WKInterfaceImage!
        @IBOutlet weak var cityNameLabel: WKInterfaceLabel!
        @IBOutlet weak var weatherDescriptionLabel: WKInterfaceLabel!
        @IBOutlet weak var temperatureLabel: WKInterfaceLabel!
        @IBOutlet weak var pressureLabel: WKInterfaceLabel!
        @IBOutlet weak var humidityLabel: WKInterfaceLabel!
        
        
        let locationManager = CLLocationManager()
    
        var weatherData = WeatherData()



        func startLocationManager()
        {
            locationManager.requestWhenInUseAuthorization()
            
            if CLLocationManager.locationServicesEnabled()
            {
                locationManager.delegate = self
                locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
                //locationManager.pausesLocationUpdatesAutomatically = false
                locationManager.startUpdatingLocation()
            }
        }
        
        func updateView()
        {
            cityNameLabel.setText(weatherData.name)
            //weatherDescriptionLabel.setText(DataSource.weatherIDs[weatherData.weather[0].id])
            temperatureLabel.setText(weatherData.main.temp.description + "°C")
            pressureLabel.setText( weatherData.main.pressure.description)
            humidityLabel.setText(weatherData.main.humidity.description)
            weatherIconImageView.setImage(UIImage(named: weatherData.weather[0].icon))
            
        }
        
        func updateWeatherInfo(latitude: Double, longtitude: Double)
        {
            let session = URLSession.shared
            let url = URL(string: "http://api.openweathermap.org/data/2.5/weather?lat=\(latitude.description)&lon=\(longtitude.description)&units=metric&lang=ru&APPID=8a5ab6a3f55f9872b9c54490cc17d0fa")!
            let task = session.dataTask(with: url)
            {
                (data, response, error)  in
                guard error == nil else
                {
                    print("DataTask error: \(error!.localizedDescription)")
                    return
                }
                do
                {
                    self.weatherData = try JSONDecoder().decode(WeatherData.self, from: data!)
                    DispatchQueue.main.async
                    {
                        self.updateView()
                    }
                }
                catch
                {
                    print(error.localizedDescription)
                }
            }
            task.resume()
        }
}

    /*extension InterfaceController: CLLocationManagerDelegate
    {
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
        {
            if let lastLocation = locations.last
            {
                updateWeatherInfo(latitude: lastLocation.coordinate.latitude, longtitude: lastLocation.coordinate.longitude)
            }
        }
    }*/

